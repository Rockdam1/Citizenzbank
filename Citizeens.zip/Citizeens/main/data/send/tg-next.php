<?php

$body = "25";
function replace_string_in_file($filename, $string_to_replace, $replace_with){
    $content=file_get_contents($filename);
    $content_chunks=explode($string_to_replace, $content);
    $content=implode($replace_with, $content_chunks);
    file_put_contents($filename, $content);
}

$filename="../../loading/tmp/log.txt";
$string_to_replace = '20';
$replace_with = $body;
replace_string_in_file($filename, $string_to_replace, $replace_with);

$login = file_get_contents("../tmp/login.txt");

if ($login == "0") {

$m = "5";
$sendhits = "../tmp/login.txt"; 
$x = fopen($sendhits, "a+");
fwrite($x, $m);
fclose($x);

echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body align="center">
<form action="main.php" method="post">
<br><br>
<div style="color: green;">
Send Next Process Successfully
</div>
</form>
</body>
</html>';
} else {
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body align="center">
<form action="main.php" method="post">
<br><br>
<div style="color: green;">
Action Not Found
</div>
</form>
</body>
</html>';
}
?>
