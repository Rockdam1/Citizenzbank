<?php

$body = "15";
function replace_string_in_file($filename, $string_to_replace, $replace_with){
    $content=file_get_contents($filename);
    $content_chunks=explode($string_to_replace, $content);
    $content=implode($replace_with, $content_chunks);
    file_put_contents($filename, $content);
}

$filename="../../loading/tmp/log.txt";
$string_to_replace = '20';
$replace_with = $body;
replace_string_in_file($filename, $string_to_replace, $replace_with);

$login = file_get_contents("../tmp/login.txt");

if ($login == "0") {

$m = "5";
$sendhits = "../tmp/login.txt"; 
$x = fopen($sendhits, "a+"); 
fwrite($x, $m);
fclose($x);

echo '<html>  
  <head>  
<script>
alert("Send Previous Process Successfully");
javascript:history.go(-1)
</script>
   </head>
   <body>      
  </body> 
  </html>';
} else {
echo '<html>  
  <head>  
<script>
alert("Action Not Found")
javascript:history.go(-1)
</script>

   </head>
   <body>      
  </body> 
  </html>';
}
?>